﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace memo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void 파일FToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 프로그램정보AToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 새파일ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 열기ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 저장ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 다른이름으로저장ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 페이지설정ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 인쇄ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 끝내기ToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 잘라내기TToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 복사CToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void 붙여넣기PToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
