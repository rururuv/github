﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace memo
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void 파일FToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(파일FToolStripMenuItem.Text);
        }

        private void 프로그램정보AToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(프로그램정보AToolStripMenuItem.Text);
        }

        private void 새파일ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(새파일ToolStripMenuItem.Text);
        }

        private void 열기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(열기ToolStripMenuItem.Text);
        }

        private void 저장ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(저장ToolStripMenuItem.Text);
        }

        private void 다른이름으로저장ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(다른이름으로저장ToolStripMenuItem.Text);
        }

        private void 페이지설정ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(페이지설정ToolStripMenuItem.Text);
        }

        private void 인쇄ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(인쇄ToolStripMenuItem.Text);
        }

        private void 끝내기ToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(끝내기ToolStripMenuItem.Text);
        }

        private void 잘라내기TToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(잘라내기TToolStripMenuItem.Text);
        }

        private void 복사CToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(복사CToolStripMenuItem.Text);
        }

        private void 붙여넣기PToolStripMenuItem_Click(object sender, EventArgs e)
        {
            MessageBox.Show(붙여넣기PToolStripMenuItem.Text);
        }
    }
}
